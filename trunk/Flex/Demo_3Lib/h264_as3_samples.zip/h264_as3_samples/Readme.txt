Read the following before using the files within this archive.

This archive contains ActionScript 2.0 and ActionScript 3.0 files that accompany the article, "Exploring Flash Player support for high-definition H.264 video and AAC audio," in the Flash Developer Center:
http://www.adobe.com/devnet/flashplayer/articles/hd_video_flash_player.html

Use the files in H264_AS3_samples to create a sample H.264 video player and a sample MP4 player in Flash using ActionScript 3.0. There are both video and audio sample files, as well as FLA files for each individual walkthrough contained in the article. 

The walkthroughs for these sample files appear in the main article linked to at the beginning of this Readme file. Put the files in H264_AS3_samples in the following locations:

* backcountry_bombshells_4min_HD_H264.mp4. Save in the root directory for this project. This is the H.264 video used in the walkthrough.

* AAC_Audio_AS3_Audio_complete.fla. Save in the root directory for this project. This file has the completed code for the "Using a Sound object to control an AAC file" walkthrough.

* AAC_Audio_AS3_MetaData.fla. Save in the root directory for this project. This file has all the assets needed to start the walkthrough for extracting metadata from audio files (in "Extracting metadata from MPEG-4 files").

* AAC_Audio_AS3_Metadata_complete.fla. Save in the root directory for this project. This file has the completed code for the walkthrough for extracting metadata from audio files (in "Extracting metadata from MPEG-4 files").

* AAC_Audio_AS3_Sound.fla. Save in the root directory for this project. This file has all the assets for the "Using a Sound object to control an AAC file" walkthrough.

* AAC_Audio_AS3_Sound_complete.fla. Save in the root directory for this project. This file has the complete code for the "Using a Sound object to control an AAC file" walkthrough.

* H264_Video_AS3_audio.fla. Save in the root directory for this project. This file has the assets neeeded to start the "Using a SoundTransform object to control an H.264 file" walkthrough.

* H264_Video_AS3_audio_complete.fla. Save in the root directory for this project. This file has the complete code for the "Using a SoundTransform object to control an H.264 file" walkthrough.

* H264_Video_AS3_FullScreen.fla. Save in the root directory for this project. This file has the assets needed to start the "Using hardware scaling with full-screen video" walkthrough.

* H264_Video_AS3_FullScreen_complete.fla. Save in the root directory for this project. This file has the complete code for the "Using hardware scaling with full-screen video" walkthrough.

* H264_Video_AS3_MetaData.fla. Save in the root directory for this project. This file has the assets needed to start the walkthrough for extracting metadata from video files (in "Extracting metadata from MPEG-4 files").

* H264_Video_AS3_MetaData_complete.fla. Save in the root directory for this project. This file has the complete code for the walkthrough for extracting metadata from video files (in "Extracting metadata from MPEG-4 files").

* H264_Video_AS3_video_complete.fla. Save in the root directory for this project. This file has the complete code for the "Playing H.264 Content Using NetStream" walkthrough.

* RE-Sample.m4a. Save in the root directory for this project. This is the audio file used in the AAC walkthroughs.
