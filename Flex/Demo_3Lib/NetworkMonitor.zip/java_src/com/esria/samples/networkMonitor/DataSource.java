/*
* Used as a datasource in lieu of a database.
* Parses /data/devices.xml.
*/

package com.esria.samples.networkMonitor;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.esria.samples.networkMonitor.vo.AlertTotal;
import com.esria.samples.networkMonitor.vo.Device;
import com.esria.samples.networkMonitor.vo.DeviceEvent;

import flex.messaging.FlexContext;

public class DataSource
{
	private Device[] _devices;
	private HashMap _deviceHashMap;
	
	public DataSource()
	{
		loadXML();
	}
	
	public Device[] getDevices()
	{
		return _devices;
	}
	
	public Device getDeviceDetail(String id)
	{
		return (Device)_deviceHashMap.get(id);
	}
	
	private void loadXML()
	{
		try
		{
			/*
			HttpServletRequest request = FlexContext.getHttpRequest();
			// Create the URL to the web app.
			String absoluteContext = request.getScheme()+"://"+request.getServerName();
			int port = request.getServerPort();
			if (port!=80) absoluteContext += ":"+ String.valueOf(port);

			// Create a pointer to the "devices.xml" url.
			URL url = new URL(absoluteContext + request.getContextPath() + "/data/devices.xml");
			URLConnection urlConnection = url.openConnection();
			HttpURLConnection httpURLConnection = (HttpURLConnection) urlConnection;
			if (httpURLConnection.getResponseCode() == HttpURLConnection.HTTP_OK)
			{
				InputStream inputStream = httpURLConnection.getInputStream();
				*/
			//begin adjusted for loadbalanced
			ServletContext context = FlexContext.getServletContext();
			String path = context.getRealPath("/data/devices.xml");
			if (path != null)
			{
			//end adjusted
				FileInputStream inputStream = new FileInputStream(path);
			   	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			   	factory.setIgnoringComments(true);
			   	factory.setIgnoringElementContentWhitespace(true);
			   	
			   	DocumentBuilder documentBuilder = factory.newDocumentBuilder();
				Document document = documentBuilder.parse(inputStream);
				
				createDeviceArray(document);
			}
			else
			{
				System.out.println("Unable to open devices.xml");
			} 
		}
		catch (ParserConfigurationException e)
		{
			System.out.println("ParserConfigurationException: " + e);
		}
		catch (IOException e)
		{
			System.out.println("IOException: " + e);
		}
		catch (SAXException e)
		{
			System.out.println("SAXException: " + e);
		}
	}
	
	// Creates an Array and HashMap of the devices.
	private void createDeviceArray(Document document)
	{
		Element element = (Element) document.getDocumentElement();
		NodeList nodeList = element.getElementsByTagName("device");
		if (nodeList != null && nodeList.getLength() > 0)
		{
			// Parse through the <device> tags.
			_devices = new Device[nodeList.getLength()];
			_deviceHashMap = new HashMap();

			for (int i = 0; i < nodeList.getLength(); i++)
			{
				Element element1 = (Element) nodeList.item(i);
				NodeList deviceNodeList = element1.getChildNodes();
				Device device = new Device();
				for (int j = 0; j < deviceNodeList.getLength(); j++)
				{
					Node node = deviceNodeList.item(j);
					if (node.getNodeType() == 1 && !node.getFirstChild().getNodeValue().equals(null))
					{
						String value = node.getFirstChild().getNodeValue();
						String nodeName = node.getNodeName();
						if (nodeName.equalsIgnoreCase("id"))
							device.setId(value);
						else if (nodeName.equalsIgnoreCase("name"))
							device.setName(value);
						else if (nodeName.equalsIgnoreCase("type"))
							device.setType(value);
						else if (nodeName.equalsIgnoreCase("typeName"))
							device.setTypeName(value);
						else if (nodeName.equalsIgnoreCase("iconUrl"))
							device.setIconUrl(value);
						else if (nodeName.equalsIgnoreCase("x"))
							device.setX(Integer.parseInt(value));
						else if (nodeName.equalsIgnoreCase("y"))
							device.setY(Integer.parseInt(value));
						else if (nodeName.equalsIgnoreCase("connections"))
							device.setConnections(createConnectionsArray(node));
						else if (nodeName.equalsIgnoreCase("cpu"))
							device.setCpu(Integer.parseInt(value));
						else if (nodeName.equalsIgnoreCase("memory"))
							device.setMemory(Integer.parseInt(value));
						else if (nodeName.equalsIgnoreCase("incoming"))
							device.setIncoming(Float.parseFloat(value));
						else if (nodeName.equalsIgnoreCase("outgoing"))
							device.setOutgoing(Float.parseFloat(value));
						else if (nodeName.equalsIgnoreCase("alertTotals"))
							device.setAlertTotals(createAlertTotalsArray(node));
						else if (nodeName.equalsIgnoreCase("events"))
							device.setDeviceEvents(createDeviceEventsArray(node));
						else if (nodeName.equalsIgnoreCase("admin"))
							device.setAdmin(value);
						else if (nodeName.equalsIgnoreCase("location"))
							device.setLocation(value);
						else if (nodeName.equalsIgnoreCase("responseTime"))
							device.setResponseTime(value);
						else if (nodeName.equalsIgnoreCase("averageMemoryByMonth"))
							device.setAverageMemoryByMonth(createAverageMemoryByMonthArray(node));
					}
				}
				
				_devices[i] = device;
				_deviceHashMap.put(device.getId(), device);
			}
		}
	}
	
	/*
	 * Creates an array from a <connections> node.
	 *  <connections>
			<connection>XPA1576</connection>
		</connections>
	 */
	private String[] createConnectionsArray(Node node)
	{
		Element element = (Element) node;
		NodeList nodeList = element.getElementsByTagName("connection");
		String[] connections = new String[nodeList.getLength()];
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node conectionsNode = nodeList.item(i);
			if (conectionsNode.getNodeType() == 1 && !conectionsNode.getFirstChild().getNodeValue().equals(null))
				connections[i] = conectionsNode.getFirstChild().getNodeValue();
		}
		
		return connections;
	}
	
	/*
	 * Creates an array from an <alertTotals> node.
	 *  <alertTotals>
			<alert>
				<type>Critical</type>
				<total>16</total>
			</alert>
		</alertTotals>
	 */
	private AlertTotal[] createAlertTotalsArray(Node node)
	{
		Element element = (Element) node;
		NodeList nodeList = element.getElementsByTagName("alert");
		AlertTotal[] alerts = new AlertTotal[nodeList.getLength()];
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			AlertTotal alert = new AlertTotal();
			NodeList eventNodeList = nodeList.item(i).getChildNodes();
			for (int j = 0; j < eventNodeList.getLength(); j++)
			{
				Node eventNode = eventNodeList.item(j);
				if (eventNode.getNodeType() == 1 && !eventNode.getFirstChild().getNodeValue().equals(null))
				{
					String value = eventNode.getFirstChild().getNodeValue();
					String nodeName = eventNode.getNodeName();
					if (nodeName.equalsIgnoreCase("type"))
						alert.setType(value);
					else if (nodeName.equalsIgnoreCase("total"))
						alert.setTotal(Integer.parseInt(value));
				}
			}
			alerts[i] = alert;
		}
		
		return alerts;
	}
	
	/*
	 * Creates an array from an <events> node.
	 *  <events>
			<event>
				<date>1185946089</date>
				<description>The time service has not been able to synchronize the system time for 49152 seconds.</description>
			</event>
		</events>
	 */
	private DeviceEvent[] createDeviceEventsArray(Node node)
	{
		Element element = (Element) node;
		NodeList nodeList = element.getElementsByTagName("event");
		DeviceEvent[] deviceEvents = new DeviceEvent[nodeList.getLength()];
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			DeviceEvent deviceEvent = new DeviceEvent();
			NodeList eventNodeList = nodeList.item(i).getChildNodes();
			for (int j = 0; j < eventNodeList.getLength(); j++)
			{
				Node eventNode = eventNodeList.item(j);
				if (eventNode.getNodeType() == 1 && !eventNode.getFirstChild().getNodeValue().equals(null))
				{
					String value = eventNode.getFirstChild().getNodeValue();
					String nodeName = eventNode.getNodeName();
					if (nodeName.equalsIgnoreCase("date"))
						deviceEvent.setDate(Long.parseLong(value));
					else if (nodeName.equalsIgnoreCase("description"))
						deviceEvent.setDescription(value);
				}
			}
			deviceEvents[i] = deviceEvent;
		}
		
		return deviceEvents;
	}
	
	private int[] createAverageMemoryByMonthArray(Node node)
	{
		Element element = (Element) node;
		NodeList nodeList = element.getElementsByTagName("percent");
		int[] percents = new int[nodeList.getLength()];
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node percentsNode = nodeList.item(i);
			if (percentsNode.getNodeType() == 1 && !percentsNode.getFirstChild().getNodeValue().equals(null))
				percents[i] = Integer.parseInt(percentsNode.getFirstChild().getNodeValue());
		}
		
		return percents;
	}
}
