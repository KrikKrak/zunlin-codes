/*
*  Value object used to store device data.
*/

package com.esria.samples.networkMonitor.vo;

public class Device
{
	private String id;					// Device id.
	private String name;				// Device name.
	private String type;				// Device type, if type equals "icon" only an icon will show without data.
										// Valid values are icon, switch, server and router.
	private String typeName;			// Name for the type of device, ex: a VOIP monitor is the type name for a type of server.
	private String iconUrl;				// Used only when type equals "icon"
	private int cpu;					// CPU consumption as a percent, not used if type equals "icon".
	private int memory;					// Memory consumption as a percent, not used if type equals "icon".
	private float incoming;				// Incoming traffic in GBs, not used if type equals "icon".
	private float outgoing;				// Incoming traffic in GBs, not used if type equals "icon".
	private int x;						// Used only for the network topology view.
	private int y;						// Used only for the network topology view.
	private String[] connections;		// Array of id strings.
	private String location;			// Physical city location of the device.
	private String responseTime;		// In milliseconds.
	private String admin;				// Name of the administrator.
	private DeviceEvent[] deviceEvents;	// Array of DeviceEvent objects.
	private AlertTotal[] alertTotals;	// Array of AlertTotal objects.
	private int[] averageMemoryByMonth;	// Array of memory averages.

	public void setId(String s)
	{
		id = s;
	}
	
	public String getId()
	{
		return id;
	}
	
	public void setName(String n)
	{
		name = n;
	}
	
	public String getName()
	{
		return name;
	}

	public void setType(String t)
	{
		type = t;
	}
	
	public String getType()
	{
		return type;
	}

	public void setTypeName(String t)
	{
		typeName = t;
	}
	
	public String getTypeName()
	{
		return typeName;
	}

	public void setIconUrl(String i)
	{
		iconUrl = i;
	}
	
	public String getIconUrl()
	{
		return iconUrl;
	}

	public void setCpu(int c)
	{
		cpu = c;
	}

	public int getCpu()
	{
		return cpu;
	}

	public void setMemory(int m)
	{
		memory = m;
	}

	public int getMemory()
	{
		return memory;
	}

	public void setIncoming(float i)
	{
		incoming = i;
	}

	public float getIncoming()
	{
		return incoming;
	}

	public void setOutgoing(float o)
	{
		outgoing = o;
	}

	public float getOutgoing()
	{
		return outgoing;
	}

	public void setX(int i)
	{
		x = i;
	}

	public int getX()
	{
		return x;
	}

	public void setY(int i)
	{
		y = i;
	}

	public int getY()
	{
		return y;
	}
	
	public void setConnections(String[] c)
	{
		connections = c;
	}
	
	public String[] getConnections()
	{
		return connections;
	}
	
	public void setLocation(String l)
	{
		location = l;
	}
	
	public String getLocation()
	{
		return location;
	}
	
	public void setResponseTime(String r)
	{
		responseTime = r;
	}
	
	public String getResponseTime()
	{
		return responseTime;
	}
	
	public void setAdmin(String a)
	{
		admin = a;
	}
	
	public String getAdmin()
	{
		return admin;
	}
	
	public void setDeviceEvents(DeviceEvent[] e)
	{
		deviceEvents = e;
	}
	
	public DeviceEvent[] getDeviceEvents()
	{
		return deviceEvents;
	}
	
	public void setAlertTotals(AlertTotal[] a)
	{
		alertTotals = a;
	}
	
	public AlertTotal[] getAlertTotals()
	{
		return alertTotals;
	}
	
	public void setAverageMemoryByMonth(int[] a)
	{
		averageMemoryByMonth = a;
	}
	
	public int[] getAverageMemoryByMonth()
	{
		return averageMemoryByMonth;
	}
}