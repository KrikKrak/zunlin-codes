/*
* Used to push data to the client. 
*/

package com.esria.samples.networkMonitor;

import java.util.Random;

import com.esria.samples.networkMonitor.vo.Device;

import flex.messaging.MessageBroker;
import flex.messaging.messages.AsyncMessage;
import flex.messaging.util.UUIDUtils;

public class FeedThread extends Thread
{
	public boolean running = false;
	
	private DataSource _dataSource;
	private static int _FEED_INTERVAL = 3000;	// Interval in milliseconds to push the data.
	private static String _DESTINATION_NAME = "feed";
	
	public void setDataSource(DataSource dataSource)
	{
		_dataSource = dataSource;
	}
	
	public void run()
	{
		MessageBroker msgBroker = MessageBroker.getMessageBroker(null);
		String clientID = UUIDUtils.createUUID(false);

		Random random = new Random();

		while (running && !_dataSource.equals(null))
		{
			Device[] devices = _dataSource.getDevices();
			
			// Loop through the devices and update the properties. 
			// Since the data is not coming from a database the values are updated randomly.
			for (int i = 0; i < devices.length; i++)
			{
				Device device = devices[i];
				
				// Randomly create a cpu value.
				float randomFloat = random.nextFloat();
				int plusMinus = 1;
				if (random.nextFloat() > .5)
					plusMinus *= -1;
				
				int cpu = device.getCpu() + Math.round(randomFloat * 10) * plusMinus;
				cpu = Math.min(cpu, 100);
				cpu = Math.max(cpu, 0);
				device.setCpu(cpu);

				// Randomly create a memory value.
				randomFloat = random.nextFloat();
				if (random.nextFloat() > .5)
					plusMinus *= -1;
				
				int memory = device.getMemory() + Math.round(randomFloat * 10) * plusMinus;
				memory = Math.min(memory, 100);
				memory = Math.max(memory, 0);
				device.setMemory(memory);

				// Randomly create an incoming value.
				randomFloat = random.nextFloat();
				if (random.nextFloat() > .5)
					plusMinus *= -1;
				
				float incoming = device.getIncoming() + randomFloat * plusMinus;
				incoming = Math.min(incoming, 10);
				incoming = Math.max(incoming, 0);
				device.setIncoming(incoming);

				// Randomly create an outgoing value.
				randomFloat = random.nextFloat();
				if (random.nextFloat() > .5)
					plusMinus *= -1;
				
				float outgoing = device.getOutgoing() + randomFloat * plusMinus;
				outgoing = Math.min(outgoing, 10);
				outgoing = Math.max(outgoing, 0);
				device.setOutgoing(outgoing);
			}

			AsyncMessage msg = new AsyncMessage();
			msg.setDestination(_DESTINATION_NAME);
			msg.setClientId(clientID);
			msg.setMessageId(UUIDUtils.createUUID(false));
			msg.setTimestamp(System.currentTimeMillis());
			msg.setBody(devices);
			msgBroker.routeMessageToService(msg, null);

			try
			{
				Thread.sleep(_FEED_INTERVAL);
			}
			catch (InterruptedException e)
			{
			}

		}
	}
}