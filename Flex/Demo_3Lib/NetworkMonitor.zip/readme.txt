Network Monitor Demo Application readme

Description
This application uses Adobe LiveCycle Data Services ES for RemoteObject calls and to push data to the client.
To download LCDS go to http://www.adobe.com/go/trylivecycle_dataservices/. This application also uses the
Cairngorm framework. As of this writing, Cairngorm 2.2 is used. To download Cairngorm go to
http://labs.adobe.com/wiki/index.php/Cairngorm:Cairngorm2.2:Download. You will need the SWCs from the
links labeled "Cairngorm 2.2 Binary" and "Cairngorm Enterprise 2.2 Binary".
To learn more about Cairngorm go to http://labs.adobe.com/wiki/index.php/Cairngorm.

File and Folder Descriptions
/src/main.mxml - The main application file.
/src/FeedAdmin.mxml - Used to stop and start the pushed data feed.
/src/assets - Contains assets which are embedded into the app.
/src/com - Contains ActionScript and MXML classes.
/src/images - Contains images loaded at runtime.
/data - Contains the XML data file. XML is loaded on the server and is used in place of a database.
/java_src - Contains Java classes.
/classes - contains the compiled Java classes.


Installation Instructions
1. Unzip the contents to your install of LCDS.
2. Copy the "classes" directory to WEB-INF.
3. From the download specified above, copy Cairngorm.swc and CairngormEnterprise.swc to WEB-INF/flex/user_classes.
4. Add the following to the <service> tag in WEB-INF/flex/remoting-config.xml.
   <destination id="networkMonitor">
      <properties>
         <source>com.esria.samples.networkMonitor.NetworkMonitor</source>
      </properties>
   </destination>
6. Add the following to the <service> tag in WEB-INF/flex/messaging-config.xml.
   <default-channels>
      <channel ref="my-rtmp"/>
   </default-channels>
   <destination id="feed">
      <properties>
         <network>
            <session-timeout>0</session-timeout>
         </network>
         <server>
            <max-cache-size>1000</max-cache-size>
            <message-time-to-live>0</message-time-to-live>
            <durable>false</durable>
         </server>
      </properties>
   </destination>
5. Start your Java app server.
6. Go to http://localhost:{port}/{context-root}/main.mxml.

Flex Builder Set Up
If you would like to build the project in Flex builder be sure to add the following SWCs to your project
library path by going to Project > Properties > Flex Build Path > Library path.
WEB-INF/flex/user_classes/Cairngorm.swc
WEB-INF/flex/user_classes/CairngormEnterprise.swc
WEB-INF/flex/libs/fds.swc
