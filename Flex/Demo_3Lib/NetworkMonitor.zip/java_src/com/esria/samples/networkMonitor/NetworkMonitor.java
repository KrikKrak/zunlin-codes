/*
* Facade class used to manage the network monitor demo app.
*/

package com.esria.samples.networkMonitor;

import com.esria.samples.networkMonitor.FeedThread;
import com.esria.samples.networkMonitor.vo.Device;

public class NetworkMonitor
{
	private static FeedThread _thread;
	private static DataSource _dataSource;
	
	public Device[] getDevices()
	{
		return getDataSource().getDevices();
	}
	
	private DataSource getDataSource()
	{
		if (_dataSource == null)
			_dataSource = new DataSource();
		
		return _dataSource;
	}
	
	public Device getDeviceDetail(String id)
	{
		return _dataSource.getDeviceDetail(id);
	}
	
	public boolean startFeed()
	{
		if (_thread == null)
		{
			_thread = new FeedThread();
			DataSource dataSource = getDataSource();
			_thread.setDataSource(dataSource);
			_thread.running = true;
			_thread.start();
		}
		
		return getFeedStatus();
	}

	public boolean stopFeed()
	{
		if (_thread != null)
		{
			_thread.running = false;
			_thread = null;
		}
		
		return getFeedStatus();
	}
	
	public boolean getFeedStatus()
	{
		if (_thread == null)
			return false;
		
		return _thread.running;
	}
}